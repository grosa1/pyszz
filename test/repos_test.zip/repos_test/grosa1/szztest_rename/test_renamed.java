public class Hello {

    public static void main(String[] args) {
        double price = 2.0;
        boolean loyaltycard = true;
        int age = 20;
         if (age >= 18) {
            //check loyalty card
            if (loyaltycard) {
                //give 30% discount
                price = price * 0.7;
            }
           boolean can_watch = true;
         }
     }
 } 