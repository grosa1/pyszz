
public class Hello {

   public static void main(String[] args) {
        if (age >= 18) {
            //check loyalty card
            if (loyaltycard) {
                //give 30% discount
                price = price * 0.7;
            }
          can_watch = true;
        }
        return price;
    }

    public static void print(String str) {
        System.out.println(str);
    }
}
