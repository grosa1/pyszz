public class Compilable {
  public boolean renamedStatusXAgain = false;
  
  public void test() {
    if (!this.renamedStatusXAgain) {
      System.out.println("Hello!");
    } else {
      System.out.println("Oh no!!!!");
    }
  }
} 
